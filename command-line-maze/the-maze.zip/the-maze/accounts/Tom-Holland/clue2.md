Welcome to the second clue :]

SECOND CLUE: 

![social-media-image](socialMediaGraph.png)

I seem to have accidentally dropped this big square on the graph of the most popular social media sites. Can you check this website for the original graph and head to the next folder representing the most current, popular site? 

vv
https://www.pewresearch.org/internet/fact-sheet/social-media/