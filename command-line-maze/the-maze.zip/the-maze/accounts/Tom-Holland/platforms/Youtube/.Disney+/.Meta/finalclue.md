Hello! This is the final clue. Because this is the final clue, lets take a break from social media and play some video games, which was my alternate information area of interest. 

One game I play in my free time is Marvel Rivals. So here's the question. Which character has the highest winrate of this current season? Check this chart for the answer -> https://rivalsmeta.com/characters











(It's my hope that this maze is completed before the stats change, because Season 10 is releasing 2 days from Sep 9th. If not, check the other .md file for extra clues.)