Yay! You made it. 

Sorry for the evil clue. No hard feelings?

To make it up to you, this next one's easy. Which company recently came out with the highly privacy-contentious video-recording glasses? 

Use the name of the parent company of this organization to find the hidden file